package com.jpa_curd.curdDemo.service;

import com.jpa_curd.curdDemo.model.Customer;

import java.util.List;
import java.util.Optional;


public interface CustomerServices {

    public List<Customer> findAll();

    public Customer findById(Long id);

    public Customer save(Customer customer);

    public void deleteById(Long id);

    Optional<Customer> findByEmail(String email);

    Optional<Customer> findByPhone(String phone);


}
