package com.jpa_curd.curdDemo.Enum;

public enum Gender {
    MALE,
    FEMALE,
    OTHERS
}
