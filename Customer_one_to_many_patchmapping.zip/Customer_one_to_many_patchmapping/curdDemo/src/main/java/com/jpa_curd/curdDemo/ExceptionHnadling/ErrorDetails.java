package com.jpa_curd.curdDemo.ExceptionHnadling;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

@Getter
@Setter
@ToString
public class ErrorDetails {
    private Date date;
    private String message;
    private String path;

    public ErrorDetails(Date date, String message, String path) {
        this.date = date;
        this.message = message;
        this.path = path;

    }

}
