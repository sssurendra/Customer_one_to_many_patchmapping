package com.jpa_curd.curdDemo.model;

import com.jpa_curd.curdDemo.Enum.Gender;
import lombok.*;

import javax.persistence.*;
import java.util.List;

@ToString
@Getter
@Setter
@RequiredArgsConstructor
@Entity
@Table(name = "customer")
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "customer_id")
    private Long id;

    @Column(name = "customerName", length = 64, nullable = false)
    private String customerName;

    @Column(name = "email", length = 64, nullable = false)
    private String email;

    @Column(name = "phone", nullable = false)
    private String phone;// string

    @Enumerated(value = EnumType.STRING)
    private Gender gender;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "customer_id")
    private List<Product> products;//products, or productList

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "customer_id")
    private List<Address> addressList;
}