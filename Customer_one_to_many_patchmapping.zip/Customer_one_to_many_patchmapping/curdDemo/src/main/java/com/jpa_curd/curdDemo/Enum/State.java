package com.jpa_curd.curdDemo.Enum;

public enum State {

    ANDRAPRADESH,
    TELANGANA,
    TAMILNADU,
    KARNATAKA,
    KERALA
}
