package com.jpa_curd.curdDemo.model;

import com.sun.istack.NotNull;
import lombok.*;

import javax.persistence.*;

@ToString
@Getter
@Setter
@RequiredArgsConstructor
@Entity
@Table(name = "product")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "product_id")
    private Long product_id;

    @Column(name = "productName", length = 64, nullable = false)
    private String productName;

    @Column(name = "price",length = 10, nullable = false)
    private Long price;

    @Column(name = "description",length = 1024, nullable = false)
    private String description;


}













