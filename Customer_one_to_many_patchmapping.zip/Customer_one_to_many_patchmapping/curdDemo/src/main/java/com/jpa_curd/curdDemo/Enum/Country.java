package com.jpa_curd.curdDemo.Enum;

public enum Country {
    INDIA
}
