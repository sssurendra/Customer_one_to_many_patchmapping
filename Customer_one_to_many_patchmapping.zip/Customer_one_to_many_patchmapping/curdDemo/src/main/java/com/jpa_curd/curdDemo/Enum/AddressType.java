package com.jpa_curd.curdDemo.Enum;

public enum AddressType {
    PERMANENT,
    CURRENT,
    OFFICE
}
