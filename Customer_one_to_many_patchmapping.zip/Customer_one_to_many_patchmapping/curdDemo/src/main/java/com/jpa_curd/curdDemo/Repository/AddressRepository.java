package com.jpa_curd.curdDemo.Repository;

import com.jpa_curd.curdDemo.model.Address;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AddressRepository extends JpaRepository<Address, Long> {
}
