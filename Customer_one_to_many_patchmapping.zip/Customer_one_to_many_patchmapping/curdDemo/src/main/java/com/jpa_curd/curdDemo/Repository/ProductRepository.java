package com.jpa_curd.curdDemo.Repository;

import com.jpa_curd.curdDemo.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {
}
