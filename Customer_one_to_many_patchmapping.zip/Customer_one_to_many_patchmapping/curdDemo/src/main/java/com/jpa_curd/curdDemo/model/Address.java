package com.jpa_curd.curdDemo.model;

import com.jpa_curd.curdDemo.Enum.AddressType;
import com.jpa_curd.curdDemo.Enum.Country;
import com.jpa_curd.curdDemo.Enum.State;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;

@ToString
@Getter
@Setter
@RequiredArgsConstructor
@Entity
@Table(name = "address")
public class Address {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "house_number", length = 32, nullable = false)
    private String houseNumber;

    @Column(name = "area", length = 32, nullable = false)
    private String area;

    @Column(name = "city", length = 32, nullable = false)
    private String city;

    @Column(name = "state", length = 32, nullable = false)
    private State state;

    @Column(name = "country", length = 32, nullable = false)
    private Country country;

    @Enumerated(value = EnumType.STRING)
    private AddressType addressType;


}
